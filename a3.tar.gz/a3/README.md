# Assignment 3
This is a Juypter Notebook. If you can't run it you can look at the results at https://github.com/Alextopher/CS449-Computational-Learning/blob/main/a3/assignment3.ipynb